from django.apps import AppConfig


class PlaceupConfig(AppConfig):
    name = 'PLACEUP'
